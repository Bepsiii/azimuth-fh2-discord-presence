#include "features.h"
#include "support.h"
#include "logging.h"

/* Loaded CXML4Resource text only; no archive or EXE is written. */
#define XML_PARSE_SLOT_RVA 0x2ec4fe0u
#define XML_PARSE_RVA 0x13de7e0u
#define GAME_ALLOC_RVA 0x3229c0u
#define GAME_FREE_RVA 0x31c7b0u
#define GARAGE_GATE_RVA 0xccf660u
#define XML_MAX_SIZE (8u * 1024u * 1024u)

typedef unsigned char (*XmlParseFn)(void *resource);
typedef void *(*GameAllocFn)(size_t size);
typedef void (*GameFreeFn)(void *buffer);

typedef enum {
    GARAGE_RESOURCE_NONE = 0,
    GARAGE_RESOURCE_UI_SCREENS = 1,
    GARAGE_RESOURCE_PAUSE_FLOW = 2
} GarageResourceKind;

typedef struct {
    uint32_t begin, end;
    const char *text;
} XmlEdit;

typedef struct {
    XmlEdit edits[6];
    uint32_t count, length;
} XmlPlan;

static XmlParseFn original_xml_parse;
static GameAllocFn game_alloc;
static GameFreeFn game_free;
static unsigned char *garage_game_image;
static int xml_hook_failed;

#include "garage_flow.h"

/* Input disables are deque entries, not a boolean: release our entry before
   the outer pause flow releases its own. Consume the pause snapshot reference
   once before loading; a dedicated outer exit avoids re-enabling it on the way
   to the HUD or consuming an unrelated owner's reference. Native car loading
   and play_cutscene retain their own readiness checks. */

/* Bounded search: return length if absent or ambiguous. */
static uint32_t find_unique_text(const char *source, uint32_t length, const char *needle) {
    size_t needle_size = text_length(needle);
    uint32_t found = length;
    if (!needle_size || needle_size > length) {
        return length;
    }
    for (uint32_t offset = 0; offset <= length - (uint32_t)needle_size; ++offset) {
        if (source[offset] == needle[0] && memory_equal(source + offset, needle, needle_size)) {
            if (found != length) {
                return length;
            }
            found = offset;
        }
    }
    return found;
}

static uint32_t find_first_text(const char *source, uint32_t length, const char *needle) {
    size_t needle_size = text_length(needle);
    if (!needle_size || needle_size > length) {
        return length;
    }
    for (uint32_t offset = 0; offset <= length - (uint32_t)needle_size; ++offset) {
        if (source[offset] == needle[0] && memory_equal(source + offset, needle, needle_size)) {
            return offset;
        }
    }
    return length;
}

static int garage_plan_screen_exits(const char *block, uint32_t block_length, uint32_t start,
                                    XmlPlan *plan) {
    plan->count = 2;
    const char *back = "<exit id=\"back\" />";
    const char *transition = "<transition id=\"car_selected\" target=\".back\" />";
    uint32_t back_exit = find_unique_text(block, block_length, back),
             selected_exit = find_unique_text(block, block_length, transition);
    if (back_exit == block_length || selected_exit == block_length ||
        back_exit + text_length(back) > selected_exit ||
        find_unique_text(block, block_length,
                         "<behavior id=\"UIPageCarSelectGaragePauseMenu\" isBack=\"{IsEntry "
                         "enterback}\">") == block_length) {
        return 0;
    }
    plan->edits[0] = (XmlEdit){start + back_exit + (uint32_t)text_length(back),
                               start + back_exit + (uint32_t)text_length(back),
                               "\n    <exit id=\"car_selected\" />"};
    plan->edits[1] =
        (XmlEdit){start + selected_exit, start + selected_exit + (uint32_t)text_length(transition),
                  "<transition id=\"car_selected\" target=\".car_selected\" />"};
    return 1;
}

static int garage_plan_pause_transition(const char *source, uint32_t length, const char *block,
                                        uint32_t block_length, uint32_t start, uint32_t end,
                                        const char *closing, XmlPlan *plan) {
    uint32_t parent = find_unique_text(source, length, "<state id=\"pause_menu_flow\">");
    if (parent == length) {
        return 0;
    }
    uint32_t parent_end = find_first_text(source + parent, length - parent, "</state>") + parent;
    if (start <= parent || end >= parent_end || parent_end == length) {
        return 0;
    }
    if (find_unique_text(block, block_length,
                         "<exit id=\"back\" target=\"pause_menu.enterback\" />") == block_length ||
        find_unique_text(block, block_length, "<exit id=\"car_view\" target=\"view_car\" />") ==
            block_length ||
        find_unique_text(source, length,
                         "<node id=\"unpause_and_exit_to_hud\" state=\"global.dummy_state\">") ==
            length) {
        return 0;
    }
    plan->edits[0] =
        (XmlEdit){end, end, "<exit id=\"car_selected\" target=\"_fh2_car_store\" />\n    "};
    plan->edits[1] = (XmlEdit){end + (uint32_t)text_length(closing),
                               end + (uint32_t)text_length(closing), car_change_flow_xml};
    /* Add a dedicated exit to both levels of the pause flow. Every original
       route still uses its original pause-snapshot cleanup. The resume
       nodes sit after a node whose exits are explicit, not after the final
       wait node where implicit fall-through would affect other routes. */
    uint32_t outer = find_unique_text(source, length, "<state id=\"pause_menu_tiled_flow\">");
    uint32_t outer_end = outer == length
                             ? length
                             : find_first_text(source + outer, length - outer, "</state>") + outer;
    const char *outer_open = "<node id=\"_pause_menu_flow\" state=\"pause_menu_flow\">";
    uint32_t outer_node = find_unique_text(source, length, outer_open);
    uint32_t outer_node_end =
        outer_node == length
            ? length
            : find_first_text(source + outer_node, length - outer_node, "</node>") + outer_node;
    const char *inner_exit = "<exit id=\"exit_to_hud\" />";
    uint32_t exit_at = find_unique_text(source + parent, parent_end - parent, inner_exit) + parent;
    if (outer == length || outer_end == length || outer_node <= outer ||
        outer_node_end >= outer_end || exit_at == parent_end || exit_at >= start) {
        return 0;
    }
    const char *outer_block = source + outer_node;
    uint32_t outer_length = outer_node_end - outer_node;
    if (find_first_text(outer_block + (uint32_t)text_length(outer_open),
                        outer_length - (uint32_t)text_length(outer_open),
                        "<node ") != outer_length - text_length(outer_open) ||
        find_unique_text(outer_block, outer_length,
                         "<exit id=\"exit_to_hud\" target=\"_show_hud_and_continue\" />") ==
            outer_length ||
        find_unique_text(
            outer_block, outer_length,
            "<exit id=\"exit_behind_loading_screen\" target=\"_disable_mixer_snapshot\" />") ==
            outer_length ||
        find_unique_text(outer_block, outer_length,
                         "<exit id=\"exit_to_mie\" target=\"_show_empty_scene_and_continue\" />") ==
            outer_length) {
        return 0;
    }
    exit_at += (uint32_t)text_length(inner_exit);
    plan->edits[2] = (XmlEdit){exit_at, exit_at, "\n    <exit id=\"_fh2_car_resumed\" />"};
    plan->edits[3] = (XmlEdit){outer_node_end, outer_node_end,
                               "<exit id=\"_fh2_car_resumed\" target=\"_fh2_car_hud\" />\n    "};
    outer_node_end += (uint32_t)text_length("</node>");
    plan->edits[4] = (XmlEdit){outer_node_end, outer_node_end, car_change_resume_xml};
    plan->edits[5] =
        (XmlEdit){parent_end + (uint32_t)text_length("</state>"),
                  parent_end + (uint32_t)text_length("</state>"),
                  "\n  <state id=\"_fh2_car_store_road\"><behavior id=\"StoreCarPosition\" "
                  "entity_id=\"_fh2_car_road\" locator_name=\"\" "
                  "restore_facing_next_event=\"false\" /></state>\n"};
    plan->count = 6;
    return 1;
}

static int garage_finalize_edit_plan(XmlPlan *plan, uint32_t length) {
    for (unsigned i = 1; i < plan->count; ++i) {
        XmlEdit edit = plan->edits[i];
        unsigned j = i;
        while (j && plan->edits[j - 1].begin > edit.begin) {
            plan->edits[j] = plan->edits[j - 1];
            --j;
        }
        plan->edits[j] = edit;
    }
    uint32_t total = length;
    for (unsigned i = 0; i < plan->count; ++i) {
        if (i && plan->edits[i - 1].end > plan->edits[i].begin) {
            return 0;
        }
        total += (uint32_t)text_length(plan->edits[i].text) -
                 (plan->edits[i].end - plan->edits[i].begin);
    }
    if (total > XML_MAX_SIZE) {
        return 0;
    }
    plan->length = total;
    return 1;
}

static int garage_plan_xml_edits(const char *source, uint32_t length, unsigned resource_kind,
                                 XmlPlan *plan) {
    if (!source || !length || length > XML_MAX_SIZE ||
        (resource_kind != GARAGE_RESOURCE_UI_SCREENS &&
         resource_kind != GARAGE_RESOURCE_PAUSE_FLOW)) {
        return 0;
    }
    for (uint32_t i = 0; i < length; ++i) {
        if (!source[i]) {
            return 0;
        }
    }
    if (find_first_text(source, length, "_fh2_car_") != length) {
        return 0;
    }
    const char *opening = resource_kind == GARAGE_RESOURCE_UI_SCREENS
                              ? "<state id=\"car_select_garage_pause_menu\">"
                              : "<node id=\"_car_select_garage_pause_menu\" "
                                "state=\"ui_screens.car_select_garage_pause_menu\">";
    const char *closing = resource_kind == GARAGE_RESOURCE_UI_SCREENS ? "</state>" : "</node>";
    uint32_t start = find_unique_text(source, length, opening);
    if (start == length) {
        return 0;
    }
    uint32_t end = find_first_text(source + start, length - start, closing) + start;
    if (end == length) {
        return 0;
    }
    uint32_t block_length = end - start;
    const char *block = source + start;
    /* Only the known leaf state/node is eligible. Nested elements of the same
       type, existing car_selected exits, or changed handlers are refused. */
    uint32_t inner = (uint32_t)text_length(opening);
    if (find_first_text(block + inner, block_length - inner,
                        resource_kind == GARAGE_RESOURCE_UI_SCREENS ? "<state " : "<node ") !=
            block_length - inner ||
        find_first_text(block, block_length, "<exit id=\"car_selected\"") != block_length) {
        return 0;
    }

    int planned = resource_kind == GARAGE_RESOURCE_UI_SCREENS
                      ? garage_plan_screen_exits(block, block_length, start, plan)
                      : garage_plan_pause_transition(source, length, block, block_length, start,
                                                     end, closing, plan);
    return planned && garage_finalize_edit_plan(plan, length);
}

static void garage_apply_xml_edits(const char *source, uint32_t length, const XmlPlan *plan,
                                   char *destination) {
    uint32_t input = 0, output = 0;
    for (unsigned i = 0; i < plan->count; ++i) {
        const XmlEdit *edit = &plan->edits[i];
        uint32_t size = edit->begin - input;
        memory_copy(destination + output, source + input, size);
        output += size;
        size = (uint32_t)text_length(edit->text);
        memory_copy(destination + output, edit->text, size);
        output += size;
        input = edit->end;
    }
    memory_copy(destination + output, source + input, length - input);
    destination[plan->length] = 0;
}

static void garage_disable_action_on_failure(const char *message) {
    __atomic_store_n(&xml_hook_failed, 1, __ATOMIC_SEQ_CST);
    log_append(message);
    /* A partial/unsupported resource change must not expose the new action. */
    DWORD old, ignored;
    if (garage_game_image && memory_equal(garage_game_image + GARAGE_GATE_RVA, "\x90\x90", 2)) {
        if (VirtualProtect(garage_game_image + GARAGE_GATE_RVA, 2, PAGE_EXECUTE_READWRITE, &old)) {
            *(volatile uint16_t *)(garage_game_image + GARAGE_GATE_RVA) = 0x7474;
            FlushInstructionCache(GetCurrentProcess(), garage_game_image + GARAGE_GATE_RVA, 2);
            VirtualProtect(garage_game_image + GARAGE_GATE_RVA, 2, old, &ignored);
            log_append("GARAGE: Get In Car disabled for this session.\r\n");
        } else {
            log_append("GARAGE: failed to restore the Get In Car menu restriction.\r\n");
        }
    }
}

static unsigned garage_identify_resource(const unsigned char *resource) {
    const char *name = (const char *)(resource + 0xb8);
    size_t length = *(const size_t *)(resource + 0xc8),
           capacity = *(const size_t *)(resource + 0xd0);
    if (!length || length > 4096 || capacity < length) {
        return 0;
    }
    if (capacity >= 16) {
        name = *(const char *const *)(resource + 0xb8);
    }
    if (!name) {
        return 0;
    }
    size_t start = 0;
    for (size_t i = 0; i < length; ++i) {
        if (name[i] == '/' || name[i] == '\\') {
            start = i + 1;
        }
    }
    const char *names[] = {"ui_screens.xml", "pause.xml"};
    for (unsigned kind = 1; kind <= 2; ++kind) {
        const char *expected = names[kind - 1];
        size_t n = text_length(expected);
        if (length - start != n) {
            continue;
        }
        size_t i;
        for (i = 0; i < n; ++i) {
            char ch = name[start + i];
            if (ch >= 'A' && ch <= 'Z') {
                ch += 'a' - 'A';
            }
            if (ch != expected[i]) {
                break;
            }
        }
        if (i == n) {
            return kind;
        }
    }
    return 0;
}

static unsigned char garage_parse_resource_hook(void *game_resource) {
    unsigned char *resource = game_resource;
    unsigned resource_kind = garage_identify_resource(resource);
    if (resource_kind && !__atomic_load_n(&xml_hook_failed, __ATOMIC_SEQ_CST)) {
        char **buffer = (char **)(resource + 0xe0);
        uint32_t *length = (uint32_t *)(resource + 0xe8);
        XmlPlan plan;
        if (!garage_plan_xml_edits(*buffer, *length, resource_kind, &plan)) {
            garage_disable_action_on_failure(
                "GARAGE: unsupported menu-flow text; car reload unavailable.\r\n");
        } else {
            char *replacement = game_alloc((size_t)plan.length + 1);
            if (!replacement) {
                garage_disable_action_on_failure(
                    "GARAGE: menu-flow allocation failed; car reload unavailable.\r\n");
            } else {
                garage_apply_xml_edits(*buffer, *length, &plan, replacement);
                char *original_buffer = *buffer;
                *buffer = replacement;
                *length = plan.length;
                game_free(original_buffer);
                log_append(
                    resource_kind == GARAGE_RESOURCE_UI_SCREENS
                        ? "GARAGE: ui_screens.xml car_selected exit patched in memory.\r\n"
                        : "GARAGE: pause.xml car reload/resume sequence patched in memory.\r\n");
                if (resource_kind == GARAGE_RESOURCE_PAUSE_FLOW) {
                    log_append(
                        "GARAGE: loading screen and fast-travel arrival animation enabled.\r\n");
                }
                if (resource_kind == GARAGE_RESOURCE_PAUSE_FLOW) {
                    log_append(
                        "GARAGE: transition input locks balanced; loading radio resumed.\r\n");
                }
                if (resource_kind == GARAGE_RESOURCE_PAUSE_FLOW) {
                    log_append("GARAGE: direct audio handoff; world-streaming and LOD0 waits "
                               "removed.\r\n");
                }
            }
        }
    }
    unsigned char result = original_xml_parse(resource);
    if (resource_kind && !result) {
        garage_disable_action_on_failure(
            "GARAGE: original XML parser failed; car reload unavailable.\r\n");
    }
    return result;
}

/* Unlike the fixed EXE ranges, this pointer is relocated by the game loader
   and its replacement points into this DLL. It is never normalized on disk. */
static unsigned char hook_original_bytes[8], hook_target_bytes[8];
static const unsigned char *const hook_accepted[] = {hook_original_bytes, hook_target_bytes};
PatchDefinition garage_hook_patch = {XML_PARSE_SLOT_RVA,
                                     0,
                                     8,
                                     GROUP_PAUSE_GARAGE,
                                     "garage_xml_parse_hook",
                                     hook_original_bytes,
                                     hook_target_bytes,
                                     hook_target_bytes,
                                     hook_accepted,
                                     2};

void garage_prepare_hook(unsigned char *game_image) {
    uintptr_t original_callback = (uintptr_t)(game_image + XML_PARSE_RVA),
              replacement_callback = (uintptr_t)garage_parse_resource_hook;
    memory_copy(hook_original_bytes, &original_callback, 8);
    memory_copy(hook_target_bytes, &replacement_callback, 8);
    original_xml_parse = (XmlParseFn)original_callback;
    game_alloc = (GameAllocFn)(game_image + GAME_ALLOC_RVA);
    game_free = (GameFreeFn)(game_image + GAME_FREE_RVA);
    garage_game_image = game_image;
    __atomic_store_n(&xml_hook_failed, 0, __ATOMIC_SEQ_CST);
}

void *garage_callback_address(void) {
    return (void *)garage_parse_resource_hook;
}
#ifdef FH2_TWEAKS_TEST
__declspec(dllexport) void *Fh2TestXmlHookAddress(void) {
    return (void *)garage_parse_resource_hook;
}

__declspec(dllexport) uint32_t Fh2TestXmlTransform(const char *input, uint32_t length,
                                                   unsigned kind, char *output, uint32_t capacity) {
    XmlPlan plan;
    if (!garage_plan_xml_edits(input, length, kind, &plan) || !output || capacity <= plan.length) {
        return 0;
    }
    garage_apply_xml_edits(input, length, &plan, output);
    return plan.length;
}
#endif
